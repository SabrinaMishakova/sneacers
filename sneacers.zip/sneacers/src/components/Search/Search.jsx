import './Search.css'

export default function Search() {
    return (
        <>
            <div className="search">
                <h2>Все кросовки</h2>
                <form action="">
                    <input placeholder='🔎  Поиск' type="search" />
                </form>
            </div>
        </>

    )
}

