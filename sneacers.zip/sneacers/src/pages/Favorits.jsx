import Empty from "../components/Empty/Empty";

export default function Favorits(){
    return(
        <>
            <Empty emodji="🥺" text="Закладок нет :(" textmini="Вы ничего не добавляли в закладки" />
        </>
    )
}