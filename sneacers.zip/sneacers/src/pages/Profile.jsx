import Empty from "../components/Empty/Empty";

export default function Profile(){
    return(
        <>
            <Empty emodji="😞" text="У вас нет заказов" text2="Оформите хотя бы один заказ." />
        </>
    )
}